export interface DetalleVenta {
  id?: number;
  idVenta: number;
  cantidad: number;
  descripcion: string;
  preciounitario: number;
  importe: number;
}
