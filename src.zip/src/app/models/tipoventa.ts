export interface Tipoventa {
  id:number;
  tipoventa:string;
}
