export interface Formapago{
  id:number;
  formapago:string;
}
