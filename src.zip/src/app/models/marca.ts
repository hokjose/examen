export interface Marca {
 id:number;
  marca:string;
}
