export interface Genero{
  id: number;
  genero:string;
}
