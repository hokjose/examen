export interface Cliente{
  id:number;
  nombre:string;
  dni:string;
}
