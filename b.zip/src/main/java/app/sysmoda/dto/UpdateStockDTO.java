package app.sysmoda.dto;

import lombok.Data;

@Data
public class UpdateStockDTO {
private Integer stock;
}
