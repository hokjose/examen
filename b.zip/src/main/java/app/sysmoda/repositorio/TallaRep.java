package app.sysmoda.repositorio;

import app.sysmoda.modelo.Talla;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TallaRep extends JpaRepository<Talla, Long> {
}
