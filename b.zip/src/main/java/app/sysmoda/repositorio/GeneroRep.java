package app.sysmoda.repositorio;

import app.sysmoda.modelo.Genero;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GeneroRep extends JpaRepository<Genero, Long> {
}
