package app.sysmoda.servicios;

import app.sysmoda.modelo.FormaPago;
import java.util.List;

public interface FormaPagoService {
    List<FormaPago> findAll();

}
