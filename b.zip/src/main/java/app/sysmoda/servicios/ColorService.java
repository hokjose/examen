package app.sysmoda.servicios;

import app.sysmoda.modelo.Color;

import java.util.List;

public interface ColorService {
    List<Color> findAll();
}
