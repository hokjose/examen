package app.sysmoda.servicios;

import app.sysmoda.modelo.Talla;
import java.util.List;

public interface TallaService {
    List<Talla> findAll();
}
