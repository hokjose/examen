package app.sysmoda.servicios;

import app.sysmoda.modelo.Genero;
import app.sysmoda.modelo.Marca;

import java.util.List;

public interface GeneroService {
    List<Genero> findAll();
}
