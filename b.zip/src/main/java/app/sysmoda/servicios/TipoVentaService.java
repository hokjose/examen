package app.sysmoda.servicios;

import app.sysmoda.modelo.TipoVenta;

import java.util.List;

public interface TipoVentaService {
    List<TipoVenta> findAll();
}
