package app.sysmoda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SysmodaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SysmodaApplication.class, args);
    }

}
